<script setup>
    import bilde from '@/bilder/ja.jpg'
</script>

<template>
<main>
 <section>
        <img :src = "bilde" alt = "" width = "300">
        <span>gaming</span>
 </section>
    <button>Another!</button>
</main>
</template>

<style scoped>
main {
    background: #CCD6D9;
    max-width:90%;
    border-radius:0 15px 0 15px;
    padding:35px;
    display:flex;
    flex-direction:column;
    align-items:center;
    gap:10px;
}

 section {
    display: flex;
    width:100%;
    flex-direction:column;
    gap:10px;
    margin-bottom:25px;
}

img{
    font-weight:bold;
    font-style: italic;
    font-size:2rem;
    text-align:left;
}

 img::before {
    content: '"'
}

img::after {
    content: '"'
}

span {
    align-self:end;
    color: #406473;
}

span::before {
    content: "- "
}

button {
    background:#406473;
    color: white;
    padding:10px;
    border: 0;
    font-size:1.2rem;
    border-radius:0 5px 0 5px;
    font-weight:bold;
    margin-top:20px;
    cursor:pointer;
    transition: transform 0.2s;
}
button:hover{
    transform: scale(1.05);
}
</style>