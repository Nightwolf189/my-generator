<script setup>
</script>

<template>
<header>
    <h1>my generator</h1>
</header>
</template>

<style scoped>
header {
    color:#CCD6D9;
    margin-bottom:25px;
}
</style>
