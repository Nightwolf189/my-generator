<script setup>
import Header from '@/komponenter/Header.vue'
import Main from '@/komponenter/Main.vue'
import Footer from '@/komponenter/Footer.vue'
</script>

<template>
    <Header/>
    <Main/>
    <Footer/>
</template>

<style scoped>
</style>
